﻿using STTech.BytesIO.Serial;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Test.BytesIO.Serial.Desktop
{
    public partial class MainForm : Form
    {
        // 串口连接客户端
        private SerialClient client;

        public MainForm()
        {
            InitializeComponent();

            // 创建串口通信客户端
            client = new SerialClient();

            
 
            client.BaudRate = 4800;
            client.Parity = System.IO.Ports.Parity.None;

            client.StopBits = System.IO.Ports.StopBits.Two;


            // 向下拉选项框中添加所有串口名称
            cbPort.Items.AddRange(client.GetPortNames());

            // 监听连接成功事件
            client.OnConnectedSuccessfully += Client_OnConnectedSuccessfully;
            // 监听连接失败事件
            client.OnConnectionFailed += Client_OnConnectionFailed;
            // 监听断开连接事件
            client.OnDisconnected += Client_OnDisconnected;
            // 监听接收数据事件
            client.OnDataReceived += Client_OnDataReceived;
            // 监听发送数据事件
            client.OnDataSent += Client_OnDataSent;
            // 监听发生异常事件
            client.OnExceptionOccurs += Client_OnExceptionOccurs;
        }

        private void Client_OnExceptionOccurs(object sender, STTech.BytesIO.Core.Entity.ExceptionOccursEventArgs e)
        {
            Print($"异常: {e.Exception.Message}\r\n");
        }

        private void Client_OnDataSent(object sender, STTech.BytesIO.Core.Entity.DataSentEventArgs e)
        {
            Print($"r\n发送: {e.Data.ToHexCodeString()}({e.Data.EncodeToString()})\r\n");
        }

        private void Client_OnDataReceived(object sender, STTech.BytesIO.Core.Entity.DataReceivedEventArgs e)
        {
            Print($"r\n接收: {e.Data.ToHexCodeString()}({e.Data.EncodeToString()})\r\n");
        }

        private void Client_OnDisconnected(object sender, STTech.BytesIO.Core.Entity.DisconnectedEventArgs e)
        {
            Print("断开连接\r\n");
        }

        private void Client_OnConnectionFailed(object sender, STTech.BytesIO.Core.Entity.ConnectionFailedEventArgs e)
        {
            Print("连接失败\r\n");
        }

        private void Client_OnConnectedSuccessfully(object sender, STTech.BytesIO.Core.Entity.ConnectedSuccessfullyEventArgs e)
        {
            Print("连接成功\r\n");
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
           

            if (string.IsNullOrWhiteSpace(cbPort.Text))
            {
                return;
            }

            client.PortName = cbPort.Text;
            client.Connect();
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            client.Disconnect();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            byte[] t = new byte[8];

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x01;
            t[4] = 0x00;
            t[5] = 0xff;
            t[6] = 0x00;
            t[7] = 0x00;
 
            client.Send(t);

        }













        /// <summary>
        /// 打印日志
        /// </summary>
        /// <param name="msg"></param>
        private void Print(string msg)
        {
            Invoke(new EventHandler(delegate
            {
                tbRecv.AppendText($"[{DateTime.Now.ToLongTimeString()}] {msg}\r\n");
            }));
        }

        private void tbSend_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            byte[] t = new byte[8];

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(100); //毫秒

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x08;
            t[4] = 0x03;
            t[5] = 0xE7;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(100); //毫秒


            

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x02;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(100); //毫秒

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x03;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(100); //毫秒





            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x01;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);


        }

        private void button3_Click(object sender, EventArgs e)
        {
            byte[] t = new byte[8];


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(100); //毫秒


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x03;
            t[4] = 0x01;
            t[5] = 0xF4;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);
            System.Threading.Thread.Sleep(100); //毫秒

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x08;
            t[4] = 0x03;
            t[5] = 0xE8;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);
            System.Threading.Thread.Sleep(100); //毫秒



            

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x02;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(100); //毫秒







            System.Threading.Thread.Sleep(100); //毫秒

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x01;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);





        }

        private void button2_Click(object sender, EventArgs e)
        {
            byte[] t = new byte[8];

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x03;
            t[4] = 0x03;
            t[5] = 0xE8;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);










            System.Threading.Thread.Sleep(50); //毫秒



           


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x02;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x08;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒





            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x01;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);




        }

       

        private void button7_Click(object sender, EventArgs e)
        {
            byte[] t = new byte[8];

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x06;
            t[4] = 0x00;
            t[5] = 0x01;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            byte[] t = new byte[8];

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x06;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            byte[] t = new byte[8];
            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x01;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            byte[] t = new byte[8];
            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);
        }

        private void tbRecv_TextChanged(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            byte[] t = new byte[8];
           

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x02;
            t[4] = (byte)(((uint)trackBar3.Value) >> 8);
            t[5] = (byte)(((uint)trackBar3.Value));
            t[6] = 0x00;
            t[7] = 0x00;
            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒
            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x03;
            t[4] = (byte)(((uint)trackBar2.Value) >> 8);
            t[5] = (byte)(((uint)trackBar2.Value));
            t[6] = 0x00;
            t[7] = 0x00;
            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x08;
            t[4] = (byte)(((uint)trackBar1.Value) >> 8);
            t[5] = (byte)(((uint)trackBar1.Value));
            t[6] = 0x00;
            t[7] = 0x00;
            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒



        }

        private void button10_Click(object sender, EventArgs e)
        {
            byte[] t = new byte[8];
            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);
        }

        private void button11_Click(object sender, EventArgs e)
        {


            byte[] t = new byte[8];

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x01;
            t[4] = 0x07;
            t[5] = 0xcc;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x02;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x03;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x08;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒

            System.Threading.Thread.Sleep(50); //毫秒


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x01;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(1000); //毫秒

            /////////////////
            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x02;
            t[4] = 0x07;
            t[5] = 0xcc;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒



            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x01;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x03;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x08;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒





            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x01;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(1000); //毫秒

            ///////////////
            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x03;
            t[4] = 0x07;
            t[5] = 0xcc;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);




            System.Threading.Thread.Sleep(50); //毫秒


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x01;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x02;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x08;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒




            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x01;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(1000); //毫秒

            ///////////////////////////

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒

            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x08;
            t[4] = 0x07;
            t[5] = 0xcc;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x01;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x02;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒



            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x03;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒





            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x01;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);






            System.Threading.Thread.Sleep(1000); //毫秒


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x04;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(50); //毫秒



            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x06;
            t[4] = 0x00;
            t[5] = 0x01;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

            System.Threading.Thread.Sleep(1000); //毫秒


            t[0] = 0x01;
            t[1] = 0x06;
            t[2] = 0x00;
            t[3] = 0x06;
            t[4] = 0x00;
            t[5] = 0x00;
            t[6] = 0x00;
            t[7] = 0x00;

            client.Send(t);

        }
    }
}
